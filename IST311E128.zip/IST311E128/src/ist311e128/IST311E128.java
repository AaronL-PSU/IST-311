/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e128;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311E128 {

    /**
     * @param args the command line arguments
     */
    public static int intParam;
    public static int i;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);   
        System.out.println("Enter a number: ");
        intParam = sc.nextInt();   
        i=intParam;
        oddNums(intParam);
    }
        public static void oddNums(int intP){
        
       
        if(i>=0){
            if (i % 2 != 0) {
                System.out.print(i + " ");
            }
            i--;
            oddNums(i);
            }
        }
}
