/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e630;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311E630 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner substanceInput = new Scanner(System.in); 
        System.out.println("Enter the substance name: "); //assigns string value to user input
        String strSub = substanceInput.nextLine();
        System.out.println("Enter the half life time in years: "); //assigns int value to user input
        int intHL = substanceInput.nextInt();
        
        System.out.println(strSub + " takes " + intHL*5.64385619 + " years to reach 2% of its original mass");
        
        /*
        This question had a big issue in the way it was written. It does not require a loop to solve.
        The number of times you divide x by 2 to reach .02x will always be the same.
        You just have to solve: 1/(2^x)=.02 which is x=5.64385619
        So it will always take 5.64385619 half lives for any substance to reach 2% of its original mass
        */
    }
    
}
