/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e125real;

import java.util.Arrays;

/**
 *
 * @author Aaron
 */
public class IST311E125Real {

    /**
     * @param args the command line arguments
     */
    public static int i=0;
    public static StringBuilder sBuilder = new StringBuilder();
    public static void main(String[] args) {
        double dblArray[] = {12.2,6.3,87.99, 123.4, 0.001};
        System.out.println("Array of doubles: " + Arrays.toString(dblArray));
        
        concatenate(dblArray);
        
    }
    public static void concatenate(double[] dblAin){
        
       
        if(i<dblAin.length){
            sBuilder.append(dblAin[i] + " ");
            i++;
            concatenate(dblAin);
        }
        else{
            System.out.println("Concatenated into one string: "+ sBuilder);
        }
    }
}
