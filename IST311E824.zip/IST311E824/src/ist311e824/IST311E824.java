/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ist311e824;

import java.util.Scanner;

/**
 *
 * @author awl5472
 */
public class IST311E824 {

    /**
     * @param args the command line arguments
     */
    //adapted from https://www.javatpoint.com/program-to-find-the-frequency-of-characters
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        System.out.println("Enter text to check letter frequency: ");
        String strIn = userInput.nextLine();
        int[] freq = new int[strIn.length()];  //creating an array the same size as the input string
        int i, j;  //counter variables
        
        char chArray[] = strIn.toCharArray(); //input string to an array of chars
                for(i = 0; i <strIn.length(); i++) {  
            freq[i] = 1;  //steps through input and sets frequency of each letter to 1
            for(j = i+1; j <strIn.length(); j++) {  
                if(chArray[i] == chArray[j]) {  //steps through array and checks for a match, increments up each time
                    freq[i]++;  
                      
                    //Set string[j] to 0 to avoid printing visited character  
                    chArray[j] = '0';  
                }  
            }  
        }  
          
        //Displays each character and their frequency  
        System.out.println("Character frequencies");  
        for(i = 0; i <freq.length; i++) {  //steps through array again to print char frequencies
            if(chArray[i] != ' ' && chArray[i] != '0')  //if it isn't a space and isn't 0, prints it
                System.out.println(chArray[i] + ": " + freq[i]);  
        }  
    }  
        
    }
    
