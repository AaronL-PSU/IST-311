/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e816;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311E816 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //adapted from https://www.javatpoint.com/how-to-take-array-input-in-java
        
int row, col, iRow, iCol;         
Scanner sc=new Scanner(System.in);   
System.out.print("Enter the number of rows: ");   
//taking row as input  
row = sc.nextInt();   
System.out.print("Enter the number of columns: ");   
//taking column as input  
col = sc.nextInt();   
int inputArray[][] = new int[row][col];
// Declaring the two-dimensional matrix
System.out.println("Enter the elements of the array: ");   
//loop for row  
for (iRow = 0; iRow < row; iRow++)   
//inner for loop for column  
for (iCol = 0; iCol < col; iCol++)   
inputArray[iRow][iCol] = sc.nextInt(); 
System.out.println("Elements of the array are: ");   
for (iRow = 0; iRow < row; iRow++)   
{   
for (iCol = 0; iCol < col; iCol++)   
//prints the array elements  
System.out.print(inputArray[iRow][iCol] + " ");   
//throws the cursor to the next line
System.out.println(); 

    }

System.out.println("Sum of elements of the array: " + sum(inputArray));
    }
    //adapted from https://stackoverflow.com/questions/49967001/java-find-sum-of-2d-array-of-numbers
    public static int sum(int[][] array) {
    int sum = 0;
    for (int[] innerArray : array)
        for (int i : innerArray)
            sum += i;
    return sum;
}
}
