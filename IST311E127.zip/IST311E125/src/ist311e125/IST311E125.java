/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e125;

import java.util.Arrays;

/**
 *
 * @author Aaron
 */
public class IST311E125 {

    /**
     * @param args the command line arguments
     */
    public static int i=0;
    public static StringBuilder sBuilder = new StringBuilder();
    public static void main(String[] args) {
        String sArray[] = {"Item1", "Item2", "Item3", "Item4", "Item5"};
        System.out.println("Array of strings: " + Arrays.toString(sArray));
        
        concatenate(sArray);
        
    }
    public static void concatenate(String[] sAin){
        
       
        if(i<sAin.length){
            sBuilder.append(sAin[i] + " ");
            i++;
            concatenate(sAin);
        }
        else{
            System.out.println("Concatenated into one string: "+ sBuilder);
        }
    }
    
}
