/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311gcd;

import java.math.BigInteger;

/**
 *
 * @author Aaron
 */
public class Logic {

 public static int GCDcalc(int number1, int number2){
    BigInteger bInt1 = BigInteger.valueOf(number1); //converts inputs to BigIntegers so they work with the GCD function
    BigInteger bInt2 = BigInteger.valueOf(number2);
    
    BigInteger result = bInt1.gcd(bInt2); //calculates GCD
    return result.intValue(); //returns result to front end
     
      
}//end method GCDcalc
    
}//end class Logic
