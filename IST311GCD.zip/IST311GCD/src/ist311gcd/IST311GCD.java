/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311gcd;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311GCD {

public static int intFirstNum; //declaring user input variables
public static int intSecondNum;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner userColorInput = new Scanner(System.in);
        System.out.println("Choose an input text color - enter one of the following: BLACK, RED, GREEN, YELLOW, BLUE, PURPLE, CYAN, WHITE");

        String colorChoice = userColorInput.nextLine(); //allows user to change the color of their input text
        switch(colorChoice){
                            case "BLACK":
                System.out.println(ConsoleColors.BLACK + "You chose: BLACK");
                break;
                            case "RED":
                System.out.println(ConsoleColors.RED + "You chose: RED");
                break;
                            case "GREEN":
                System.out.println(ConsoleColors.GREEN + "You chose: GREEN");
                break;
                            case "YELLOW":
                System.out.println(ConsoleColors.YELLOW + "You chose: YELLOW");
                break;
                            case "BLUE":
                System.out.println(ConsoleColors.BLUE + "You chose: BLUE");
                break;
                            case "PURPLE":
                System.out.println(ConsoleColors.PURPLE + "You chose: PURPLE");
                break;
                            case "CYAN":
                System.out.println(ConsoleColors.CYAN + "You chose: CYAN");
                break;
                            case "WHITE":
                System.out.println(ConsoleColors.WHITE + "You chose: WHITE");
                break;
        }
            
        
    Scanner userInput = new Scanner(System.in);  //take user input for numbers
    System.out.println("Enter first number: ");
    intFirstNum = userInput.nextInt(); 
    System.out.println("Enter second number: ");  
    intSecondNum = userInput.nextInt(); 
    
    int intGCD = Logic.GCDcalc(intFirstNum, intSecondNum); //calls GCD calculation method to begin calculation in the Logic class
    System.out.println("The Greatest Common Denominator of " + intFirstNum + " and " + intSecondNum + " is " + intGCD);
        
    }//end main
    
}//end class IST311GCD
