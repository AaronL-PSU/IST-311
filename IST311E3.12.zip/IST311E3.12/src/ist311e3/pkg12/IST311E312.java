/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e3.pkg12;

/**
 *
 * @author Aaron
 */
public class IST311E312 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        hello("Bill");
    }
    public static void hello(String strIn){
        System.out.println("Hello " + strIn);
    }
    
}
