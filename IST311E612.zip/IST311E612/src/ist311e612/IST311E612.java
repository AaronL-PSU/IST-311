/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e612;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311E612 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner numInput = new Scanner(System.in); 
        System.out.println("Enter a number: "); //assigns int value to user input
        int intInput= numInput.nextInt();
        int i=0; 
        while(i<(intInput-1)){ //counts up by 2 and prints each even number until it hits the given value
            i+=2;
            System.out.println(i);
        }
        
    }
    
}
