/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e1219;

import java.util.Scanner;

/**
 *
 * @author Aaron
 */
public class IST311E1219 {

    /**
     * @param args the command line arguments
     */
    public static int i;
    public static int intRotate;
    public static String strRotate;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in); 
        System.out.println("Enter a string: ");
        strRotate = sc.nextLine();
        System.out.println("Enter a number to rotate it by: ");
        intRotate = sc.nextInt();   
        i=0;
        rotateR(strRotate, intRotate);
    }
    public static void rotateR(String sIn, int intIn){
        if (i<=intIn){
            sIn = sIn.substring(sIn.length() - i)+sIn;
            sIn= sIn.substring(0, sIn.length()-i);
            System.out.println("Rotating " + strRotate + " by " + intRotate + ": " + sIn);
            i++;
            rotateR(strRotate, intRotate);
        }
        else{
            System.out.println("Done");
        }
    }
}
