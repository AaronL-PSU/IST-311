/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ID2;

import java.awt.geom.Point2D;
import java.util.Objects;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Initial program design
/*************************************************************************************/

public class Circle extends TwoDShape 
{
   private double dblRadius;   
   public boolean bDebugging = false;
   public Circle(Point2D.Double ptIn, double dblInRadius)
   {
       if(bDebugging == true)
       {    
          System.out.println("In Circle constructor with parameters:");    
          System.out.println("   Centered at " + ptIn);
          System.out.println("   And a radius of " + dblInRadius);
       }  
      super.setPtCenter(ptIn);
      setDblRadius(dblInRadius);
      
   }// constructor
   
   public double getDblRadius()
   {
      return dblRadius;   
   }// getRadius
   
   private void setDblRadius(double dblInRadius) throws IllegalArgumentException
   {
      if(dblInRadius > 0)
      {
         dblRadius = dblInRadius;
         setDblArea();
         setDblPerimeter();
      }   
      else
         throw new IllegalArgumentException("Input radius (" + dblInRadius + " must be greater than zero (0).");
   }// setRadius

    @Override
    public void setDblArea() 
    {
       double radius = getDblRadius();    
       if(radius > 0)   
          dblArea = Math.PI * (radius * radius);    
    }

    @Override
    public int compareTo(Object o) throws NullPointerException, ClassCastException
    {
       int intResult;
       Circle cIn = (Circle) o;

       intResult = (int)(this.getDblArea() - cIn.getDblArea());
       if (intResult == 0)        
          return (int)(this.getPtCenter().distance(cIn.getPtCenter()));
       else
          return intResult; 
    }

  
   public String toString()
   {
      StringBuilder sbOut = new StringBuilder(this.getClass().getName());
      sbOut.append(super.toString());
      sbOut.append("\n   radius = " + getDblRadius());
   //    System.out.println("sbOut = " + sbOut);
       
//       System.out.println("Superclass =  " + this.getClass().getSuperclass().toString());
//      if(Objects.nonNull(this.getClass().getSuperclass().getName()))
//      {        
//         sbOut.insert(0, super.toString() + strClassNameSeparator);
// //  System.out.println("sbOut = " + sbOut);         
//      } // if
      return sbOut.toString();
   }// toString

public void setDblPerimeter()
{
   super.setDblPerimeter(2 * Math.PI * getDblRadius());
}// setDblPerimeter

}// Circle