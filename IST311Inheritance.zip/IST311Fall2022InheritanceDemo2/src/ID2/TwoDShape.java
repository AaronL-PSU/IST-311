/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ID2;


import static ID2.Shape.strClassNameSeparator;
import java.awt.geom.Point2D;
import java.beans.PropertyChangeSupport;
import java.util.Objects;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Initial program design
/*************************************************************************************/

public abstract class TwoDShape extends Shape 
{
   private Point2D.Double ptCenter;
   protected double dblPerimeter;
   private int intNumSides;

    /**
     * @return the ptCenter
     */
    public Point2D getPtCenter() {
        return ptCenter;
    }

    /**
     * @param ptCenter the ptCenter to set
     */
    public void setPtCenter(Point2D.Double ptCenter) {
        Point2D.Double oldPtCenter = this.ptCenter;
        this.ptCenter = ptCenter;
        propertyChangeSupport.firePropertyChange(PROP_PTCENTER, oldPtCenter, ptCenter);
    }

    /**
     * @return the intNumSides
     */
    public int getIntNumSides() {
        return intNumSides;
    }

    /**
     * @param intNumSides the intNumSides to set
     */
    public void setIntNumSides(int intNumSides) {
        int oldIntNumSides = this.intNumSides;
        this.intNumSides = intNumSides;
        propertyChangeSupport.firePropertyChange(PROP_INTNUMSIDES, oldIntNumSides, intNumSides);
    }
    private final transient PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    public static final String PROP_PTCENTER = "ptCenter";
    public static final String PROP_INTNUMSIDES = "intNumSides";
    


   public String toString()
   {
    //   System.out.println("In TwoDShape");
    //  StringBuilder sbOut = new StringBuilder("TwoDShape");
       StringBuilder sbOut = new StringBuilder();
       sbOut.append("\n  centered at " + getPtCenter());
       sbOut.append("\n  perimeter = " + getDblPerimeter());
       sbOut.append("\n  area      = " + getDblArea());
      
       
//      if(Objects.nonNull(this.getClass().getSuperclass().getName()))  
//         sbOut.insert(0, super.toString() + strClassNameSeparator);
//       System.out.println(sbOut.toString());
      return sbOut.toString();
   }// toString

    /**
     * @return the dblPerimeter
     */
    public double getDblPerimeter() 
    {
        return dblPerimeter;
    }

    /**
     * @param dblInPerimeter the dblPerimeter to set
     */
    public void setDblPerimeter(double dblInPerimeter) throws IllegalArgumentException 
    {
        if(dblInPerimeter > 0)
           dblPerimeter = dblInPerimeter;
        else
           throw new IllegalArgumentException("The perimeter ("
              + dblInPerimeter + ")must be greater than zero (0)"
                   + "");    
    }
}// Shape
