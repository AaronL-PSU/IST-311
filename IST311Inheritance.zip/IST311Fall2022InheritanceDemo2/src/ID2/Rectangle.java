package ID2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import ID2.TwoDShape;
import java.awt.geom.Point2D;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Initial program design
/*************************************************************************************/

public class Rectangle extends TwoDShape 
{
   protected double dblHeight;
   protected double dblWidth;
   
   public Rectangle(Point2D.Double inPtCenter, double dblInHeight, double dblInWidth)
   {
      setPtCenter(inPtCenter);
      setDblHeight(dblInHeight);
      setDblWidth(dblInWidth);
      setDblPerimeter();
      setDblArea();
   }
    @Override
    public void setDblArea() 
    {
         dblArea = (getDblHeight() * getDblWidth());    
    }
    
 
    public void setDblPerimeter() throws IllegalArgumentException
    {
       double dH = getDblHeight();
       double dW = getDblWidth();
       
       if((dH > 0) && (dW > 0))
          dblPerimeter = ((dH * 2) + (dW *2));
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the dblHeight
     */
    public double getDblHeight() {
        return dblHeight;
    }

    /**
     * @param dblHeight the dblHeight to set
     */
    public void setDblHeight(double dblHeight) {
        this.dblHeight = dblHeight;
    }

    /**
     * @return the dblWidth
     */
    public double getDblWidth() {
        return dblWidth;
    }

    /**
     * @param dblWidth the dblWidth to set
     */
    public void setDblWidth(double dblWidth) {
        this.dblWidth = dblWidth;
    }

    public String toString()
    {
       StringBuilder  sbOut = new StringBuilder();
       sbOut.append(getClass().getName());
       sbOut.append(this.getClass().getSuperclass().getName());
        System.out.println(super.toString());
       sbOut.append("  height    = " + getDblHeight());
       sbOut.append("  width     = " + getDblWidth());
      
       
       return sbOut.toString();
    }
}// Rectangle
