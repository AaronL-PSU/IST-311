package ID2;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Tester
{
   int intNumObjects = 0;
   int intNumTypes = 3;
	
   
public Point2D.Double makeDblPoint(int intMaxY, int intMaxX)
{
   Random randXY = new Random();    
   int intY = randXY.nextInt(0, intMaxY+1);
   int intX = randXY.nextInt(0, intMaxX);
   return new Point2D.Double(intX, intY);
}
   
public Circle makeCircle()
{
   return new Circle(makeDblPoint(25,20),5);
}// makeCircle

public Rectangle makeRectangle()
{
   return new Rectangle(makeDblPoint(25,20), 8,9);
}// makeRectangle

public Square makeSquare()
{
   return new Square(makeDblPoint(25,20), 11);    
}// makeSquare

public Tester()
{
    Square myS = makeSquare();
    System.out.println("My Square = " + myS);
   
    try
    {    
       ArrayList<TwoDShape> alShapes = new ArrayList(intNumObjects);   
       Random myRand = new Random();
       int intShapeType = 0;
       for(int intLCV = 0; intLCV < intNumObjects; intLCV++)
       {
          intShapeType = myRand.nextInt(0, intNumTypes);
          
           switch (intShapeType) 
           {
               case 0 -> alShapes.add(makeCircle());
               case 1 -> alShapes.add(makeRectangle());
               case 2 -> alShapes.add(makeSquare());
               default -> {}// default
           }// switch                
       }// for    
     
//	Circle myC = new Circle(new Point2D.Double(5,10),5);
//        alShapes.add(myC);
	// System.out.println("myC = " + myC);
        
        
//        Rectangle myR = new Rectangle(new Point2D.Double(5,6), 8,9);
       //  System.out.println("myR = " + myR);
//        alShapes.add(myR);
//        Square myS = new Square(new Point2D.Double(10,15), 11);
       //  System.out.println("myS = " + myS);
//       alShapes.add(myS);
       
       Iterator iShapes = alShapes.iterator();
       
        System.out.println("alShapes has " + alShapes.size() + " items.");
       
       while(iShapes.hasNext() == true)
       {                    
           System.out.println(iShapes.next());
       }// while    
    }// try

    catch(IllegalArgumentException iae)    
    {
        System.out.println(iae);    
    }    
} // constructor
	
	
public static void main(String[] args)
{
   Tester myT = new Tester();	
} // main	
}// Tester