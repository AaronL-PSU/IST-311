/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ID2;

import java.awt.geom.Point2D;
import java.util.Objects;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Initial program design
/*************************************************************************************/

public class Square extends Rectangle 
{
    
    public Square(Point2D.Double dblCtr, double dblSide)
    {
       super(dblCtr, dblSide, dblSide);    
    }

    public String toString()
    {
        StringBuilder sbOut = new StringBuilder(getClass().getName());
        Object oTemp = this;
       while(Objects.nonNull(oTemp.getClass().getSuperclass()))
       {
           
        oTemp = getClass().getSuperclass();
       
        sbOut.insert(0, strClassNameSeparator);
        sbOut.insert(0, oTemp.getClass().getName());
                }// while
       return sbOut.toString();
      // return getClass().getCanonicalName() + " -> " + super.toString();
    }// toString
}// class Square