/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ID2;

import java.awt.Color;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Initial program design
/*************************************************************************************/

public abstract class Shape implements Comparable, Serializable 
{
   protected double dblArea;
   
   private Color cBorder;
   private int intBorderWidth;
   private Color cBackground;
   
   public static final String strClassNameSeparator = " -> ";
   
   
           

    /**
     * @return the dblArea
     */
    public double getDblArea() 
    {
        return dblArea;
    }

    /**
     * @param dblArea the dblArea to set
     */
    public abstract void setDblArea();
       
    

    /**
     * @return the cBorder
     */
    public Color getcBorder() 
    {
        return cBorder;
    }

    /**
     * @param cBorder the cBorder to set
     */
    public void setcBorder(Color cInBorder) {
        java.awt.Color oldcBorder = getcBorder();
        cBorder = cInBorder;
        propertyChangeSupport.firePropertyChange(PROP_CBORDER, oldcBorder, cInBorder);
    }

    /**
     * @return the intBorderWidth
     */
    public int getIntBorderWidth() 
    {
        return intBorderWidth;
    }

    /**
     * @param intBorderWidth the intBorderWidth to set
     */
    public void setIntBorderWidth(int intInBorderWidth) {
        int oldIntBorderWidth = intBorderWidth;
        this.intBorderWidth = intInBorderWidth;
        propertyChangeSupport.firePropertyChange(PROP_INTBORDERWIDTH, oldIntBorderWidth, intInBorderWidth);
    }

    /**
     * @return the cBackground
     */
    public Color getcBackground() 
    {
        return cBackground;
    }

    /**
     * @param cBackground the cBackground to set
     */
    public void setcBackground(Color cInBackground) 
    {
        java.awt.Color oldcBackground = cBackground;
        cBackground = cInBackground;
        propertyChangeSupport.firePropertyChange(PROP_CBACKGROUND, oldcBackground, cInBackground);
    }
    

    
 
   @Override
      public String toString()
   {
        StringBuilder sbOut = new StringBuilder("Shape");
     
      return sbOut.toString();
   } //toString 
      
    private final transient PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    public static final String PROP_DBLAREAL = "dblArea";
    public static final String PROP_CBORDER = "cBorder";
    public static final String PROP_INTBORDERWIDTH = "intBorderWidth";
    public static final String PROP_CBACKGROUND = "cBackground";
}// Shape
