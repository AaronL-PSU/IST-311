package ID2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import ID2.TwoDShape;
import java.awt.geom.Point2D;

/**
 *
 * @author whb108
 */

/***************************************  MODIFICATION LOG  **************************/
/*                                                                                   */
/*   Added regular hexagon (irregular hexagons are basically impossible to create within the bounds of this program
/*************************************************************************************/

public class RegularPentagon extends TwoDShape 
{
   protected double DblSide;
   
   public RegularPentagon(Point2D.Double inPtCenter, double dblInSide)
   {
      setPtCenter(inPtCenter);
      setDblSide(dblInSide);
      setDblPerimeter();
      setDblArea();
   }
    @Override
    public void setDblArea() 
    {
         dblArea = (((1/4)*(Math.sqrt(5*5+(2*Math.sqrt(5))))))*(getDblSide())*(getDblSide()); 
    }
    
 
    public void setDblPerimeter() throws IllegalArgumentException
    {
       double dS = getDblSide();
       
       if(dS > 0)
          dblPerimeter = (dS * 5);
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the dblHeight
     */
    public double getDblSide() {
        return DblSide;
    }

    /**
     * @param dblHeight the dblHeight to set
     */
    public void setDblSide(double dblSide) {
        this.DblSide = dblSide;
    }

    public String toString()
    {
       StringBuilder  sbOut = new StringBuilder();
       sbOut.append(getClass().getName());
       sbOut.append(this.getClass().getSuperclass().getName());
        System.out.println(super.toString());
       sbOut.append("  side    = " + getDblSide());
      
       
       return sbOut.toString();
    }
}// Rectangle
