/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist311e3.pkg20;

/**
 *
 * @author Aaron
 */
public class IST311E320 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mcdonald();
        eieio();
        System.out.println("And on his farm he had some cows");
        eieio();
        System.out.println("With a");
        cow();
        cow();
        System.out.println("here");
        System.out.println("And a");
        cow();
        cow();
        System.out.println("there");
        System.out.println("Here a");
        cow();
        System.out.println("There a");
        cow();
        System.out.println("Everywhere a");
        cow();
        cow();
        
        mcdonald();
        eieio();
        mcdonald();
        eieio();
        System.out.println("And on his farm he had some chicks");
        eieio();
        System.out.println("With a");
        chicken();
        chicken();
        System.out.println("here");
        System.out.println("And a");
        chicken();
        chicken();
        System.out.println("there");
        System.out.println("Here a");
        chicken();
        System.out.println("There a");
        chicken();
        System.out.println("Everywhere a");
        chicken();
        chicken();
        
        mcdonald();
        eieio();
        mcdonald();
        eieio();
        System.out.println("And on his farm he had some pigs");
        eieio();
        System.out.println("With a");
        pig();
        pig();
        System.out.println("here");
        System.out.println("And a");
        pig();
        pig();
        System.out.println("there");
        System.out.println("Here a");
        pig();
        System.out.println("There a");
        pig();
        System.out.println("Everywhere a");
        pig();
        pig();
        mcdonald();
        eieio();
        
        
    }
    public static void eieio(){
        System.out.println("Ee i ee i o");
}
    public static void mcdonald(){
        System.out.println("Old MacDonald had a farm");
    }
    public static void cow(){
        System.out.println("moo");
    }
    public static void chicken(){
        System.out.println("cluck");
    }
    public static void pig(){
        System.out.println("oink");
    }
}
